# тест
import pytest


def calculate_sum_from_string(nums_string):
    nums = nums_string.split(',')
    nums = [int(num) for num in nums]
    return sum(nums)


def test_calculate_sum_from_string():
    assert calculate_sum_from_string('12,34,56') == 102
    assert calculate_sum_from_string('0') == 0
    assert calculate_sum_from_string('-1,0,1') == 0
