# тест
import pytest


def count_digits(num):
    return len(str(abs(num)))


def test_count_digits():
    assert count_digits(12345) == 5
    assert count_digits(0) == 1
    assert count_digits(-987654321) == 9
