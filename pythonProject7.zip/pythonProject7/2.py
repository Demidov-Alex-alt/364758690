# тест
import pytest


def check_even(num):
    if num % 2 == 0:
        return True
    else:
        return False


def test_check_even():
    assert check_even(4) == True
    assert check_even(7) == False
    assert check_even(0) == True
