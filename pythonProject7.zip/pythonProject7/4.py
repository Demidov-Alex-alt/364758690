# тест
import pytest


def calculate_sum(lst):
    return sum(lst)


def test_calculate_sum():
    assert calculate_sum([1, 2, 3, 4, 5]) == 15
    assert calculate_sum([-1, -2, 0, 1, 2]) == 0
    assert calculate_sum([]) == 0
