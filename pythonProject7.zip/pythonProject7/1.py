# тест
import pytest


def check_negative(num):
    if num < 0:
        return True
    else:
        return False


def test_check_negative():
    assert check_negative(-5) == True
    assert check_negative(0) == False
    assert check_negative(10) == False
